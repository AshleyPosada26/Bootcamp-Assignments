from django.shortcuts import render, redirect
from django.contrib import messages
from . models import *

# Create your views here.
def index(request):
    context = {
        'courses': Course.objects.all()
    }
    return render(request, 'new_course.html', context)

def create(request): 
    if request.method == "POST":
        errors = Course.objects.basic_validator(request.POST)
        if len(errors) > 0:
            for key, value in errors.items():
                messages.error(request, value)
        else:
            course = Course.objects.create(
                name = request.POST['name'])

            description = Description.objects.create(content=request.POST['description'])
            course.description = description
            course.save()

    return redirect('/')

def course(request, course_id):
    one_course = Course.objects.get(id=course_id)
    context = {
        'course': one_course
    }
    return render(request, 'delete.html', context)

def delete(request, course_id):
    if request.method == "POST":
        to_delete = Course.objects.get(id=course_id)
        to_delete.delete()
    return redirect('/')

def comment(request, course_id):
    context = {
        "course": Course.objects.get(id=course_id)
    }
    return render(request, 'comments.html', context)

def create_comment(request, course_id):
    errors = Comment.objects.basic_validator(request.POST)
    if len(errors):
        for key, value in errors.items():
                messages.error(request, value)
    else:
        Comment.objects.create(
            content=request.POST['content'],
            course = Course.objects.get(id=course_id)
        )
    return redirect(f"/courses/{course_id}")