from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('create', views.create),
    path('courses/<int:course_id>', views.comment),
    path('courses/<int:course_id>/comment', views.create_comment),
    path('courses/destroy/<int:course_id>', views.course),
    path('courses/destroy/courses/delete/<int:course_id>', views.delete),
]