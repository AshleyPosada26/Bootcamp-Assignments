from django.apps import AppConfig


class AppSurveyConfig(AppConfig):
    name = 'app_survey'
