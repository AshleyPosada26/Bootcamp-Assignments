from django.urls import path     
from . import views
urlpatterns = [
    path('', views.submit_form),
    path('survey', views.submitted_info),
    path('result', views.end_result),
]
