from django.shortcuts import render, redirect
def submit_form(request):
    return render(request, "index.html")

def submitted_info(request):
    if request.method == 'GET':
        return redirect('')
    request.session['end_result'] = {
        'name': request.POST['full_name'],
        'location': request.POST['dojo_location'],
        'language': request.POST['favorite_language'],
        'comment': request.POST['comment'],
    }
    return redirect('/result')

def end_result(request):
    context = {
        'end_result': request.session['end_result']
    }
    return render(request, "submitted_info.html", context)




# Create your views here.
